<?php


$bot_API_KEY          = '8164189385:AAEfhXBZ957mzUFNUt4igJLC6X_DokHySNg';

$manger       = "@A_15H_S";    #Manger username
$IDcontrol    = 6793064302;   #Manger ID

#Other mangers  usernames as '@F_F_4','@DF00D'
$otherMangers    = ['@F_F_4'];

$buyBanID    = -1002403148005; #Buy and Ban Notices
$fullID            = -1002403148005; #Full completely Numbers
$fullID2         = -1002403148005; #قناة التفعيلات
$cardsID       = -1002403148005; #Notices signup and cards


?>